# config.py
"""
Central configuration for the NexterMC bot.

Everything that used to be a hardcoded "magic number" scattered across
cogs (category IDs, channel IDs, the owner ID) now lives here and can be
overridden with an environment variable without touching code. This
matters once the server is large — IDs change, categories get
reorganized, staff rotate — and you don't want to grep six files to
update one number.
"""
from __future__ import annotations

import os


def _int_env(name: str, default: int) -> int:
    """Read an integer env var, falling back to a default if unset/invalid."""
    raw = os.getenv(name)
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _int_list_env(name: str) -> list[int]:
    """Read a comma-separated list of ints from an env var. Empty if unset."""
    raw = os.getenv(name)
    if not raw:
        return []
    out = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    return out


# ---------------------------------------------------------------------------
# Ownership / staff
# ---------------------------------------------------------------------------
# Falls back to the original hardcoded value if OWNER_ID isn't set in the
# environment, so existing deployments keep working without changes.
OWNER_ID = _int_env("OWNER_ID", 1006250810142883851)

# Optional: explicit staff role IDs. If set, membership in ANY of these
# roles grants staff access, in addition to the Manage Channels permission
# check already in place. Recommended once the server has 10k+ members and
# staff roles are the real source of truth rather than ad-hoc permissions.
STAFF_ROLE_IDS = _int_list_env("STAFF_ROLE_IDS")

# ---------------------------------------------------------------------------
# Hosting plan categories (used by the AI ticket-analysis cogs to figure out
# which pricing tier a ticket belongs to)
# ---------------------------------------------------------------------------
CATEGORY_FREE_ID = _int_env("CATEGORY_FREE_ID", 1505564682482618368)
CATEGORY_PAID_ID = _int_env("CATEGORY_PAID_ID", 1456919500602474651)

PLAN_CONTEXT_MAP = {
    CATEGORY_FREE_ID: "Free Cloud Hosting (Invite-based)",
    CATEGORY_PAID_ID: "Paid Cloud Hosting Plan",
}
DEFAULT_PLAN_CONTEXT = "General Support"


def plan_context_for_category(category_id) -> str:
    """Resolve a Discord category_id to a human-readable plan label."""
    try:
        category_id = int(category_id) if category_id is not None else None
    except (TypeError, ValueError):
        category_id = None
    return PLAN_CONTEXT_MAP.get(category_id, DEFAULT_PLAN_CONTEXT)


# ---------------------------------------------------------------------------
# Channels
# ---------------------------------------------------------------------------
EVENT_RULES_CHANNEL_ID = _int_env("EVENT_RULES_CHANNEL_ID", 1419933431399452753)
MAIN_SERVER_CONSOLE_ID = _int_env("MAIN_SERVER_CONSOLE_ID", 1539875653036281937)

# ---------------------------------------------------------------------------
# Minecraft network nodes
# ---------------------------------------------------------------------------
MINECRAFT_SERVERS = {
    "Velocity Proxy": "ultimate-1.nextercloud.com:25565",
    "Main Server": "ultimate-1.nextercloud.com:19163",
    "PvP Server": "ultimate-1.nextercloud.com:19165",
}

# ---------------------------------------------------------------------------
# AI / summarization tuning
# ---------------------------------------------------------------------------
GROQ_MODEL_ID = os.getenv("GROQ_MODEL_ID", "openai/gpt-oss-120b")

# Character budget per chunk when map-reducing a long transcript. Keeps each
# individual Groq call comfortably inside context limits regardless of how
# long the underlying ticket is.
TRANSCRIPT_CHUNK_CHAR_LIMIT = _int_env("TRANSCRIPT_CHUNK_CHAR_LIMIT", 9000)

# Cooldown (seconds) applied per-user to the expensive AI commands so a
# 10,000-member server can't accidentally (or deliberately) hammer the Groq
# API and run up cost / rate-limit errors.
AI_COMMAND_COOLDOWN_SECONDS = _int_env("AI_COMMAND_COOLDOWN_SECONDS", 20)

# Brand strings, kept in one place so a rename doesn't require a find/replace
# across every embed in the codebase.
BRAND_NAME = os.getenv("BRAND_NAME", "NexterMC")
HOST_NAME = os.getenv("HOST_NAME", "NexterCloud")
