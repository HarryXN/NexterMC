# main.py
import logging
import os

import discord
from discord.ext import commands
from dotenv import load_dotenv

from config import BRAND_NAME
from permissions import is_staff_member
from utils.storage import init_db

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
)
log = logging.getLogger("nextermc.main")

intents = discord.Intents.default()
intents.message_content = True
intents.guilds = True
intents.members = True

bot = commands.Bot(command_prefix=",", intents=intents, help_command=None)
TOKEN = os.getenv("DISCORD_TOKEN")


# ==========================================
# GLOBAL PERMISSION CHECK (APPLIES TO ALL COMMANDS)
# ==========================================
@bot.check
async def globally_enforce_owner_or_staff(ctx: commands.Context) -> bool:
    if is_staff_member(ctx):
        return True
    raise commands.CheckFailure("❌ You don't have permission to use this command!")


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError):
    # Unwrap discord.py's wrapper so we react to the real error type.
    error = getattr(error, "original", error)

    if isinstance(error, commands.CheckFailure):
        await ctx.send(str(error) or "❌ You don't have permission to use this command!", delete_after=5)
        return

    if isinstance(error, commands.CommandOnCooldown):
        await ctx.send(
            f"⏳ That command is on cooldown — try again in {error.retry_after:.0f}s.",
            delete_after=5,
        )
        return

    if isinstance(error, commands.MissingRequiredArgument):
        await ctx.send(f"❌ Missing argument: `{error.param.name}`. Check `,help` for usage.", delete_after=8)
        return

    if isinstance(error, commands.BadArgument):
        await ctx.send("❌ Couldn't understand one of the arguments you gave. Check `,help` for usage.", delete_after=8)
        return

    if isinstance(error, commands.MissingPermissions):
        await ctx.send("❌ I don't have the Discord permissions needed to do that.", delete_after=8)
        return

    if isinstance(error, commands.CommandNotFound):
        return  # silent — don't spam a 10k-member server with "unknown command" noise

    # Anything else: log the full traceback server-side, tell the user
    # something generic. Never dump raw exception text into a public
    # channel — it can leak internal paths/config details.
    log.exception("Unhandled error in command %s", getattr(ctx.command, "qualified_name", "?"), exc_info=error)
    await ctx.send("❌ Something went wrong running that command. The issue has been logged.", delete_after=8)


async def load_cogs():
    cog_folder = "./cogs"
    if not os.path.exists(cog_folder):
        log.warning("Directory %s not found!", cog_folder)
        return

    for filename in sorted(os.listdir(cog_folder)):
        if not filename.endswith(".py") or filename.startswith("_"):
            continue
        module_path = f"cogs.{filename[:-3]}"
        try:
            await bot.load_extension(module_path)
            log.info("Loaded extension: %s", module_path)
        except Exception:
            log.exception("Failed to load %s", module_path)


@bot.event
async def on_ready():
    activity = discord.Activity(
        type=discord.ActivityType.playing, name=f"{BRAND_NAME} Moderation"
    )
    await bot.change_presence(activity=activity)
    log.info("Logged in as %s (%s)", bot.user, bot.user.id)
    log.info("In %d guild(s), bot is ready.", len(bot.guilds))


@bot.event
async def setup_hook():
    await init_db()
    await load_cogs()


def main():
    if not TOKEN:
        log.error("DISCORD_TOKEN environment variable is missing! Refusing to start.")
        return
    bot.run(TOKEN, log_handler=None)  # logging already configured above


if __name__ == "__main__":
    main()
