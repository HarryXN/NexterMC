# utils/storage.py
"""
Minimal persistence layer, backed by SQLite.

The original bot kept warnings in a plain in-memory dict, which means a
restart — including every single deploy on Railway — silently erased the
server's entire moderation history. For a community of a few dozen people
that's an annoyance; for one with 10,000 members it's a liability (an
appeal with "you have no warnings on file" because the file didn't survive
a redeploy).

This uses the stdlib's sqlite3, no extra service required. All calls are
synchronous under the hood but run via asyncio.to_thread so they never
block the event loop.

NOTE: on platforms with an ephemeral filesystem (Railway's default,
without an attached volume), this file is reset on every redeploy just
like the old in-memory dict was — but it now also survives simple crashes
and restarts *between* deploys, which the old code did not. For full
durability across deploys, attach a persistent volume and point
NEXTERMC_DB_PATH at a file inside it.
"""
from __future__ import annotations

import asyncio
import os
import sqlite3
from contextlib import contextmanager

DB_PATH = os.getenv("NEXTERMC_DB_PATH", "data/nextermc.db")


def _ensure_dir():
    directory = os.path.dirname(DB_PATH)
    if directory:
        os.makedirs(directory, exist_ok=True)


@contextmanager
def _connect():
    _ensure_dir()
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def _init_sync():
    with _connect() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS warnings (
                warn_id     INTEGER,
                guild_id    INTEGER NOT NULL,
                user_id     INTEGER NOT NULL,
                reason      TEXT NOT NULL,
                moderator   TEXT NOT NULL,
                created_at  TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, warn_id)
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS warning_counters (
                guild_id INTEGER PRIMARY KEY,
                next_id  INTEGER NOT NULL DEFAULT 1
            )
            """
        )
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS invites (
                guild_id    INTEGER NOT NULL,
                inviter_id  INTEGER NOT NULL,
                joined_id   INTEGER NOT NULL,
                joined_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (guild_id, joined_id)
            )
            """
        )


async def init_db():
    await asyncio.to_thread(_init_sync)


# ---------------------------------------------------------------------------
# Warnings
# ---------------------------------------------------------------------------
def _add_warning_sync(guild_id: int, user_id: int, reason: str, moderator: str) -> int:
    with _connect() as conn:
        row = conn.execute(
            "SELECT next_id FROM warning_counters WHERE guild_id = ?", (guild_id,)
        ).fetchone()
        next_id = row["next_id"] if row else 1

        conn.execute(
            "INSERT INTO warnings (warn_id, guild_id, user_id, reason, moderator) VALUES (?, ?, ?, ?, ?)",
            (next_id, guild_id, user_id, reason, moderator),
        )
        conn.execute(
            "INSERT INTO warning_counters (guild_id, next_id) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET next_id = excluded.next_id",
            (guild_id, next_id + 1),
        )
        return next_id


async def add_warning(guild_id: int, user_id: int, reason: str, moderator: str) -> int:
    return await asyncio.to_thread(_add_warning_sync, guild_id, user_id, reason, moderator)


def _remove_warning_sync(guild_id: int, warn_id: int) -> sqlite3.Row | None:
    with _connect() as conn:
        row = conn.execute(
            "SELECT * FROM warnings WHERE guild_id = ? AND warn_id = ?", (guild_id, warn_id)
        ).fetchone()
        if row is None:
            return None
        conn.execute("DELETE FROM warnings WHERE guild_id = ? AND warn_id = ?", (guild_id, warn_id))
        return row


async def remove_warning(guild_id: int, warn_id: int):
    return await asyncio.to_thread(_remove_warning_sync, guild_id, warn_id)


def _list_warnings_sync(guild_id: int, user_id: int) -> list[sqlite3.Row]:
    with _connect() as conn:
        return conn.execute(
            "SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY warn_id",
            (guild_id, user_id),
        ).fetchall()


async def list_warnings(guild_id: int, user_id: int):
    return await asyncio.to_thread(_list_warnings_sync, guild_id, user_id)


# ---------------------------------------------------------------------------
# Invite tracking
# ---------------------------------------------------------------------------
def _record_invite_join_sync(guild_id: int, inviter_id: int, joined_id: int):
    with _connect() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO invites (guild_id, inviter_id, joined_id) VALUES (?, ?, ?)",
            (guild_id, inviter_id, joined_id),
        )


async def record_invite_join(guild_id: int, inviter_id: int, joined_id: int):
    await asyncio.to_thread(_record_invite_join_sync, guild_id, inviter_id, joined_id)


def _count_invites_sync(guild_id: int, inviter_id: int) -> int:
    with _connect() as conn:
        row = conn.execute(
            "SELECT COUNT(*) AS c FROM invites WHERE guild_id = ? AND inviter_id = ?",
            (guild_id, inviter_id),
        ).fetchone()
        return row["c"] if row else 0


async def count_invites(guild_id: int, inviter_id: int) -> int:
    return await asyncio.to_thread(_count_invites_sync, guild_id, inviter_id)


def _get_inviter_sync(guild_id: int, joined_id: int):
    with _connect() as conn:
        row = conn.execute(
            "SELECT inviter_id FROM invites WHERE guild_id = ? AND joined_id = ?",
            (guild_id, joined_id),
        ).fetchone()
        return row["inviter_id"] if row else None


async def get_inviter(guild_id: int, joined_id: int):
    return await asyncio.to_thread(_get_inviter_sync, guild_id, joined_id)
