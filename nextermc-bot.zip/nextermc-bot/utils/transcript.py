# utils/transcript.py
"""
Shared transcript handling for the AI ticket-analysis cogs
(summarize / invsummary / fullsummary / solve).

Two problems the old code had, that this fixes:

1. `fullsummary` pulled the ENTIRE channel history into one giant prompt.
   On a long-lived ticket that overflows the model's context window and
   just fails. Here, long transcripts are split into char-bounded chunks,
   each chunk is analyzed into compact notes ("map"), and the notes are
   then combined into one short final answer ("reduce"). This makes the
   analysis MORE thorough on long tickets (every chunk actually gets
   read) while keeping the final output short, which is what actually
   matters to a human reading it.

2. Every cog re-implemented its own history-walking + embed-flattening
   loop slightly differently. One implementation here, used everywhere.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

import discord

from config import TRANSCRIPT_CHUNK_CHAR_LIMIT
from utils.ai_client import ask

log = logging.getLogger("nextermc.transcript")


async def fetch_transcript_lines(channel: discord.abc.Messageable, limit: int | None = None) -> list[str]:
    """Pull channel history (oldest first) into flat, model-friendly lines,
    folding embed titles/descriptions/fields into the same line so nothing
    a bot posted as an embed gets silently dropped from the analysis."""
    lines: list[str] = []
    async for message in channel.history(limit=limit, oldest_first=True):
        line = f"[{message.created_at:%Y-%m-%d %H:%M}] {message.author.display_name}: {message.content}"
        for embed in message.embeds:
            if embed.title:
                line += f" | Embed Title: {embed.title}"
            if embed.description:
                line += f" | Embed Desc: {embed.description}"
            for field in embed.fields:
                line += f" | {field.name}: {field.value}"
        lines.append(line)
    return lines


def chunk_lines(lines: list[str], char_limit: int = TRANSCRIPT_CHUNK_CHAR_LIMIT) -> list[str]:
    """Group transcript lines into chunks that stay under char_limit, so each
    chunk comfortably fits in a single model call regardless of total
    ticket length."""
    chunks: list[str] = []
    current: list[str] = []
    current_len = 0
    for line in lines:
        line_len = len(line) + 1
        if current and current_len + line_len > char_limit:
            chunks.append("\n".join(current))
            current = []
            current_len = 0
        current.append(line)
        current_len += line_len
    if current:
        chunks.append("\n".join(current))
    return chunks


@dataclass
class AnalysisResult:
    text: str
    message_count: int
    chunks_analyzed: int


_MAP_PROMPT = (
    "You are extracting facts from one part of a longer support-ticket transcript. "
    "List only concrete, verifiable facts from THIS excerpt: problems reported, exact error "
    "messages, actions staff took, bot command outputs, numbers/counts mentioned, and the "
    "current state at the end of this excerpt. Plain bullet points, no headers, no summary "
    "commentary, no speculation. If nothing notable happened in this excerpt, write 'No notable "
    "developments.'\n\n"
    f"--- TRANSCRIPT EXCERPT ---\n{{chunk}}"
)


async def analyze_transcript(lines: list[str], final_prompt_builder) -> AnalysisResult:
    """
    Map-reduce a transcript into a final answer.

    final_prompt_builder(notes: str, message_count: int) -> str
        Builds the final prompt from either the raw transcript (single
        chunk case) or the combined extraction notes (multi-chunk case).
        Keeping this as a callback lets each cog (summarize / invsummary /
        fullsummary / solve) supply its own strict output format while
        sharing the same chunking/extraction machinery.
    """
    if not lines:
        return AnalysisResult(text="", message_count=0, chunks_analyzed=0)

    chunks = chunk_lines(lines)

    if len(chunks) == 1:
        # Small enough to reason about directly — skip the extraction pass
        # entirely so short tickets don't pay for two model calls.
        final_prompt = final_prompt_builder(chunks[0], len(lines))
        text = await ask(final_prompt, temperature=0.1, max_tokens=1024)
        return AnalysisResult(text=text, message_count=len(lines), chunks_analyzed=1)

    # Multi-chunk: extract compact notes from every chunk in parallel-ish
    # (sequential awaits — the Groq SDK call already runs off-thread), then
    # combine the notes into one short final answer.
    notes = []
    for i, chunk in enumerate(chunks, start=1):
        prompt = _MAP_PROMPT.format(chunk=chunk)
        try:
            note = await ask(prompt, temperature=0.0, max_tokens=512)
        except Exception:
            log.warning("Chunk %d/%d extraction failed; skipping it", i, len(chunks))
            note = "(extraction failed for this section)"
        notes.append(f"--- Section {i}/{len(chunks)} ---\n{note}")

    combined_notes = "\n\n".join(notes)
    final_prompt = final_prompt_builder(combined_notes, len(lines))
    text = await ask(final_prompt, temperature=0.1, max_tokens=1024)
    return AnalysisResult(text=text, message_count=len(lines), chunks_analyzed=len(chunks))
