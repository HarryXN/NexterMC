# cogs/helpcmd.py
import datetime

import discord
from discord.ext import commands

from config import BRAND_NAME


class HelpCommandCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help")
    async def help_command(self, ctx):
        embed = discord.Embed(
            title=f"🌟 {BRAND_NAME} Control Panel & Command Center",
            description="Welcome to the administrative dashboard. Use prefix `,` for all commands.",
            color=discord.Color.blurple(),
        )

        embed.add_field(
            name="🛡️ Moderation",
            value=(
                "`warn <user> [reason]` — Issue a tracked warning with a global ID.\n"
                "`warn remove <id>` — Clear an active warning ID.\n"
                "`ban <user> [reason]` — Permanently ban a user.\n"
                "`unban <user_id|name>` — Pardon a banned user.\n"
                "`timeout <user> [mins] [reason]` — Temporarily mute a user.\n"
                "`untimeout <user>` — Restore speaking privileges.\n"
                "`kick <user> [reason]` — Kick a user from the server."
            ),
            inline=False,
        )

        embed.add_field(
            name="🤖 AI Ticket Analysis",
            value=(
                "`summarize` — Short, accurate overview of the current ticket.\n"
                "`invsummary` — Audits invite claims against the event rules and computes a final count.\n"
                "`fullsummary` — Deep analysis of the entire ticket history, still delivered short.\n"
                "`solve` — Either the fix, or exactly what's still missing to give one."
            ),
            inline=False,
        )

        embed.add_field(
            name="🔍 Diagnostics & Network",
            value=(
                "`check` — System + node health scan (RAM/CPU/latency/servers).\n"
                "`status` — Live status of every Minecraft server node.\n"
                "`ip` — Connection info for the Minecraft network.\n"
                "`mcprofile <username>` — Player lookup + management panel.\n"
                "`pyfiles` — Repository file listing."
            ),
            inline=False,
        )

        embed.add_field(
            name="🎟️ Invites & Accounts",
            value=(
                "`invites [user]` — Invite count for yourself or another member.\n"
                "`invited <user>` — Who invited that member.\n"
                "`accage <user>` — Account age, flags very new accounts.\n"
                "`panel` — Admin server control panel."
            ),
            inline=False,
        )

        embed.add_field(name="✨ Utility", value="`ping` — Websocket latency check.", inline=False)

        embed.set_footer(
            text=f"{BRAND_NAME} • Protected Securely",
            icon_url=ctx.bot.user.avatar.url if ctx.bot.user.avatar else None,
        )
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(HelpCommandCog(bot))
