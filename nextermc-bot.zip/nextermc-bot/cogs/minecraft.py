import datetime

import discord
from discord.ext import commands
from mcstatus import JavaServer

from config import BRAND_NAME, MINECRAFT_SERVERS


class Minecraft(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.servers = MINECRAFT_SERVERS

    @commands.command(name="status", aliases=["mcstatus", "servers"])
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def status(self, ctx):
        embed = discord.Embed(
            title=f"{BRAND_NAME} Network Status",
            description=f"Real-time health check for the {BRAND_NAME} Network.",
            color=discord.Color.blurple(),
        )
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)

        for name, address in self.servers.items():
            try:
                server = await JavaServer.async_lookup(address)
                status = await server.async_status()
                info_text = (
                    f"**Status:** 🟢 Online\n"
                    f"**Players:** `{status.players.online}/{status.players.max}`\n"
                    f"**Latency:** `{round(status.latency)}ms`\n"
                    f"**Address:** `{address}`"
                )
            except Exception:
                info_text = f"**Status:** 🔴 Offline / Unreachable\n**Address:** `{address}`"
            embed.add_field(name=name, value=info_text, inline=False)

        embed.set_footer(text=f"{BRAND_NAME} Network Monitoring")
        await ctx.send(embed=embed)

    @commands.command(name="ip", aliases=["serverip", "connect"])
    async def ip(self, ctx):
        embed = discord.Embed(
            title=f"{BRAND_NAME} Connection Info",
            description="Join our Minecraft network using the details below!",
            color=discord.Color.green(),
        )
        embed.add_field(name="Server IP (Java/Bedrock)", value="`play.nextermc.net`", inline=False)
        embed.add_field(name="Bedrock Port", value="`19132` (via Geyser)", inline=False)
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Minecraft(bot))
