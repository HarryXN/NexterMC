# cogs/fullsummary.py
import logging

import discord
from discord.ext import commands

from config import AI_COMMAND_COOLDOWN_SECONDS, plan_context_for_category
from utils.ai_client import AIConfigError
from utils.transcript import analyze_transcript, fetch_transcript_lines

log = logging.getLogger("nextermc.fullsummary")


def _build_final_prompt(source_text: str, message_count: int, plan_context: str) -> str:
    return (
        f"You are a senior auditor for NexterCloud hosting ({plan_context}), producing a master "
        "report on a long-running ticket. The material below is either the raw transcript "
        "(if short) or condensed factual notes extracted section-by-section from the full "
        "history (if long) — in the latter case, every part of the ticket has already been read, "
        "so synthesize across all sections rather than treating this as incomplete.\n\n"
        "Be short and direct. This is a report someone will actually read, not an archive — "
        "compress ruthlessly. Each bullet is at most two sentences. No filler, no repeated "
        "phrasing, no restating the plan type more than once.\n\n"
        "Output EXACTLY this Markdown format, nothing before or after it:\n"
        "### 📋 Full Ticket Master Report\n"
        f"• **Hosting Context:** {plan_context}\n"
        "• **Origin & Goal:** [why this ticket was opened]\n"
        "• **Key Milestones:** [the 2-4 developments that actually mattered, chronologically]\n"
        "• **Staff & User Actions:** [what was actually done, by whom]\n"
        "• **Current Status:** [where it stands right now, or the final resolution]\n\n"
        f"--- MATERIAL ({message_count} messages analyzed) ---\n{source_text}"
    )


class FullSummaryCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(
        name="fullsummary",
        help="Deep analysis of the entire ticket history (map-reduced so it scales to any length) — still a short report.",
    )
    @commands.cooldown(1, AI_COMMAND_COOLDOWN_SECONDS, commands.BucketType.channel)
    async def fullsummary(self, ctx):
        loading_msg = await ctx.reply("⏳ Scanning full ticket history...", mention_author=False)

        try:
            lines = await fetch_transcript_lines(ctx.channel, limit=None)
            if not lines:
                await loading_msg.edit(content="❌ No message history found.")
                return

            if len(lines) > 300:
                await loading_msg.edit(
                    content=f"🧠 Deep-analyzing {len(lines)} messages in sections — this may take a moment..."
                )

            category_id = ctx.channel.category_id if ctx.channel.category else None
            plan_context = plan_context_for_category(category_id)

            result = await analyze_transcript(
                lines, lambda src, count: _build_final_prompt(src, count, plan_context)
            )

            embed = discord.Embed(
                title="📋 NexterCloud Full Ticket Master Report",
                description=result.text[:4000],
                color=discord.Color.purple(),
            )
            embed.set_footer(
                text=(
                    f"Requested by {ctx.author.name} • {result.message_count} messages "
                    f"across {result.chunks_analyzed} section(s) analyzed"
                )
            )
            await loading_msg.delete()
            await ctx.send(embed=embed)

        except AIConfigError as e:
            await loading_msg.edit(content=f"❌ {e}")
        except Exception:
            log.exception("fullsummary failed in channel %s", ctx.channel.id)
            await loading_msg.edit(content="❌ Something went wrong generating the report. The issue has been logged.")


async def setup(bot):
    await bot.add_cog(FullSummaryCog(bot))
