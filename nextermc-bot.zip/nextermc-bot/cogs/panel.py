import datetime

import discord
from discord.ext import commands

from config import BRAND_NAME, MINECRAFT_SERVERS
from utils.console_bridge import dispatch_console


async def _require_admin(interaction: discord.Interaction) -> bool:
    if interaction.user.guild_permissions.administrator:
        return True
    await interaction.response.send_message("❌ Administrator permission required.", ephemeral=True)
    return False


class ServerSelectSubMenu(discord.ui.View):
    def __init__(self, action_type: str):
        super().__init__(timeout=180)
        self.action_type = action_type  # "start" / "stop" / "restart"

    async def _run(self, interaction: discord.Interaction, node_name: str, address: str):
        if not await _require_admin(interaction):
            return
        dispatched = await dispatch_console(interaction.client, f"{self.action_type} {node_name}")
        if dispatched:
            msg = f"⚙️ **{self.action_type.title()}** signal dispatched to **{node_name}** (`{address}`)."
        else:
            msg = "❌ Console bridge channel unavailable — signal not sent. Check `MAIN_SERVER_CONSOLE_ID`."
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Velocity Proxy", style=discord.ButtonStyle.primary, emoji="🌐")
    async def velocity_action(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._run(interaction, "Velocity Proxy", MINECRAFT_SERVERS["Velocity Proxy"])

    @discord.ui.button(label="Main Server", style=discord.ButtonStyle.success, emoji="🏡")
    async def main_action(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._run(interaction, "Main Server", MINECRAFT_SERVERS["Main Server"])

    @discord.ui.button(label="PvP Server", style=discord.ButtonStyle.danger, emoji="⚔️")
    async def pvp_action(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self._run(interaction, "PvP Server", MINECRAFT_SERVERS["PvP Server"])

    @discord.ui.button(label="⬅️ Back to Panel", style=discord.ButtonStyle.secondary)
    async def back_to_panel(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = AdminMainPanelView()
        embed = _panel_embed()
        await interaction.response.edit_message(embed=embed, view=view)


def _panel_embed() -> discord.Embed:
    embed = discord.Embed(
        title=f"⚡ {BRAND_NAME} Administrator Command Center",
        description="Select a core network operation or maintenance toggle below:",
        color=discord.Color.dark_embed(),
    )
    embed.add_field(name="Infrastructure Status", value="Use `,status` for a live per-node check.", inline=False)
    return embed


class AdminMainPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)  # persistent view

    @discord.ui.button(label="Start Servers", style=discord.ButtonStyle.success, emoji="🟢")
    async def start_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _require_admin(interaction):
            return
        view = ServerSelectSubMenu("start")
        embed = discord.Embed(
            title="🟢 Power On: Select Node",
            description="Choose which backend server node to boot up:",
            color=discord.Color.green(),
        )
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Stop Servers", style=discord.ButtonStyle.danger, emoji="🔴")
    async def stop_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _require_admin(interaction):
            return
        view = ServerSelectSubMenu("stop")
        embed = discord.Embed(
            title="🔴 Power Off: Select Node",
            description="Choose which backend server node to gracefully shut down:",
            color=discord.Color.red(),
        )
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Restart Servers", style=discord.ButtonStyle.primary, emoji="🔄")
    async def restart_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _require_admin(interaction):
            return
        view = ServerSelectSubMenu("restart")
        embed = discord.Embed(
            title="🔄 Reboot: Select Node",
            description="Choose which backend server node to restart:",
            color=discord.Color.blurple(),
        )
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Toggle Global Maintenance", style=discord.ButtonStyle.secondary, emoji="🛠️")
    async def maintenance_toggle(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _require_admin(interaction):
            return
        dispatched = await dispatch_console(interaction.client, "maintenance toggle")
        embed = discord.Embed(
            title="🛠️ Global Maintenance Mode" + (" Toggled" if dispatched else " — NOT Toggled"),
            description=(
                "Signal sent to the console bridge to toggle network-wide maintenance/whitelist."
                if dispatched
                else "❌ Console bridge channel unavailable — nothing was sent."
            ),
            color=discord.Color.gold() if dispatched else discord.Color.orange(),
        )
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        await interaction.response.send_message(embed=embed, ephemeral=True)


class AdminPanel(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="panel", aliases=["adminpanel", "control"])
    @commands.has_permissions(administrator=True)
    async def panel(self, ctx):
        embed = _panel_embed()
        embed.add_field(
            name="Network Nodes Monitored",
            value="\n".join(f"• **{name}** (`{addr}`)" for name, addr in MINECRAFT_SERVERS.items()),
            inline=False,
        )
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        embed.set_footer(text=f"{BRAND_NAME} Enterprise Core • Restricted Access")

        view = AdminMainPanelView()
        await ctx.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(AdminPanel(bot))
