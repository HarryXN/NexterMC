# cogs/solve.py
import logging

import discord
from discord.ext import commands

from config import AI_COMMAND_COOLDOWN_SECONDS, plan_context_for_category
from utils.ai_client import AIConfigError
from utils.transcript import analyze_transcript, fetch_transcript_lines

log = logging.getLogger("nextermc.solve")


def _build_final_prompt(source_text: str, message_count: int, plan_context: str) -> str:
    return (
        f"You are a lead technical support engineer for NexterCloud hosting ({plan_context}). "
        "The material below is either the raw transcript (if short) or condensed notes extracted "
        "from the full history (if long) — everything has already been read.\n\n"
        "Decide: is there enough information to solve the issue right now?\n"
        "- If NOT: give only the specific clarifying questions needed. Don't guess at a fix.\n"
        "- If YES: give a direct, step-by-step resolution. No hedging, no restating the problem "
        "at length.\n\n"
        "Be short. No filler. Output EXACTLY this Markdown format, nothing before or after it:\n"
        "### 🛠️ Problem Resolution\n"
        f"• **Hosting Context:** {plan_context}\n"
        "• **Issue:** [one sentence]\n"
        "• **Status:** [Ready to Solve / Missing Information]\n"
        "• **Clarifying Questions:** [1-3 questions, or 'None — ready to resolve']\n"
        "• **Solution:** [direct steps, or 'Pending answers above']\n\n"
        f"--- MATERIAL ({message_count} messages analyzed) ---\n{source_text}"
    )


class SolveCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(
        name="solve",
        help="Direct answer: either the step-by-step fix, or exactly what's missing to give one.",
    )
    @commands.cooldown(1, AI_COMMAND_COOLDOWN_SECONDS, commands.BucketType.channel)
    async def solve(self, ctx):
        loading_msg = await ctx.reply("🧠 Analyzing ticket...", mention_author=False)

        try:
            lines = await fetch_transcript_lines(ctx.channel, limit=None)
            if not lines:
                await loading_msg.edit(content="❌ No history found to analyze.")
                return

            category_id = ctx.channel.category_id if ctx.channel.category else None
            plan_context = plan_context_for_category(category_id)

            result = await analyze_transcript(
                lines, lambda src, count: _build_final_prompt(src, count, plan_context)
            )

            embed = discord.Embed(
                title="🧠 NexterMC Problem Solver",
                description=result.text[:4000],
                color=discord.Color.gold(),
            )
            embed.set_footer(text=f"Requested by {ctx.author.name} • Interactive Diagnostics")
            await loading_msg.delete()
            await ctx.send(embed=embed)

        except AIConfigError as e:
            await loading_msg.edit(content=f"❌ {e}")
        except Exception:
            log.exception("solve failed in channel %s", ctx.channel.id)
            await loading_msg.edit(content="❌ Something went wrong solving this. The issue has been logged.")


async def setup(bot):
    await bot.add_cog(SolveCog(bot))
