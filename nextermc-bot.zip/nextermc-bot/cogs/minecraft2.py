import datetime
import re
import uuid

import aiohttp
import discord
from discord.ext import commands, tasks
from mcstatus import JavaServer

from config import BRAND_NAME, MINECRAFT_SERVERS
from utils.console_bridge import dispatch_console, sanitize_console_arg

_USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,16}$")

# Local aliases so the rest of this file reads the same as before the helper
# was extracted to utils/console_bridge.py for reuse by panel.py.
_sanitize_console_arg = sanitize_console_arg
_dispatch_console = dispatch_console


def _staff_check(permission_name: str):
    """A component-interaction permission gate. Distinct from the
    command-level @commands.has_permissions used elsewhere because this
    guards a button click, not a command invocation — every button in this
    panel now goes through one of these instead of some being checked and
    others not."""

    async def check(interaction: discord.Interaction) -> bool:
        perms = interaction.user.guild_permissions
        if getattr(perms, permission_name, False) or perms.administrator:
            return True
        await interaction.response.send_message(
            f"❌ You need the **{permission_name.replace('_', ' ').title()}** permission to do that.",
            ephemeral=True,
        )
        return False

    return check


class BanReasonModal(discord.ui.Modal, title="AdvancedBan System — Execution"):
    reason_input = discord.ui.TextInput(
        label="Ban Reason",
        placeholder="Enter reason for punishment...",
        style=discord.TextStyle.long,
        required=True,
        max_length=250,
    )

    def __init__(self, target_name: str, target_uuid: str):
        super().__init__()
        self.target_name = target_name
        self.target_uuid = target_uuid

    async def on_submit(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.ban_members and not interaction.user.guild_permissions.administrator:
            await interaction.response.send_message("❌ Insufficient permissions.", ephemeral=True)
            return

        reason = _sanitize_console_arg(self.reason_input.value)
        dispatched = await _dispatch_console(interaction.client, f"ban {self.target_name} {reason}")

        embed = discord.Embed(
            title="🔨 AdvancedBan Dispatched via Bridge" if dispatched else "🔨 Ban NOT Dispatched — Bridge Unavailable",
            description=f"Command {'sent to' if dispatched else 'could not reach'} the Main Server console for **{self.target_name}**.",
            color=discord.Color.red() if dispatched else discord.Color.orange(),
        )
        embed.add_field(name="Target UUID", value=f"`{self.target_uuid}`", inline=False)
        embed.add_field(name="Reason", value=reason, inline=False)
        embed.add_field(name="Executed By", value=interaction.user.mention, inline=True)
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        await interaction.response.send_message(embed=embed, ephemeral=True)


class InventorySubMenu(discord.ui.View):
    def __init__(self, target_name: str, target_uuid: str):
        super().__init__(timeout=180)
        self.target_name = target_name
        self.target_uuid = target_uuid

    @discord.ui.button(label="Clear World Inventory", style=discord.ButtonStyle.danger, emoji="🌍")
    async def clear_world(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("manage_guild")(interaction):
            return
        dispatched = await _dispatch_console(interaction.client, f"clearinventory {self.target_name}")
        msg = f"✅ Cleared-inventory command sent for **{self.target_name}**." if dispatched else "❌ Bridge channel unavailable — command not sent."
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Clear Survival Inventory", style=discord.ButtonStyle.danger, emoji="⚔️")
    async def clear_survival(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("manage_guild")(interaction):
            return
        dispatched = await _dispatch_console(interaction.client, f"clear {self.target_name}")
        msg = f"✅ Clear-survival-inventory command sent for **{self.target_name}**." if dispatched else "❌ Bridge channel unavailable — command not sent."
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="⬅️ Back to Main Menu", style=discord.ButtonStyle.secondary)
    async def back_menu(self, interaction: discord.Interaction, button: discord.ui.Button):
        view = MinecraftManagementView(self.target_name, self.target_uuid)
        embed = discord.Embed(
            title=f"🛡️ Management Control Panel: {self.target_name}",
            description="Select an administrative action below to execute on **Main Server**:",
            color=discord.Color.blurple(),
        )
        await interaction.response.edit_message(embed=embed, view=view)


class MinecraftManagementView(discord.ui.View):
    def __init__(self, target_name: str, target_uuid: str):
        super().__init__(timeout=180)
        self.target_name = target_name
        self.target_uuid = target_uuid

    @discord.ui.button(label="Clear Inventory", style=discord.ButtonStyle.secondary, emoji="🧹")
    async def clear_inventory_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("manage_guild")(interaction):
            return
        view = InventorySubMenu(self.target_name, self.target_uuid)
        embed = discord.Embed(
            title="🧹 Inventory Management Hub",
            description=f"Select target inventory partition to wipe for **{self.target_name}**:",
            color=discord.Color.gold(),
        )
        await interaction.response.edit_message(embed=embed, view=view)

    @discord.ui.button(label="Query Inventory", style=discord.ButtonStyle.primary, emoji="📦")
    async def overview_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("manage_guild")(interaction):
            return
        # Honest behavior: this bridge is one-way (Discord -> console), so
        # the bot cannot actually read back live inventory data. Rather
        # than showing fabricated placeholder contents, it dispatches a
        # real inspect command and tells staff to check the in-game/console
        # output themselves.
        dispatched = await _dispatch_console(interaction.client, f"invsee {self.target_name}")
        if dispatched:
            desc = (
                f"An `invsee {self.target_name}` command was dispatched to the Main Server console. "
                "This bot cannot display live inventory contents here — check the console/plugin output "
                "in-game for the result."
            )
        else:
            desc = "❌ Bridge channel unavailable — command not sent."
        embed = discord.Embed(
            title=f"📦 Inventory Query: {self.target_name}",
            description=desc,
            color=discord.Color.blurple(),
        )
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @discord.ui.button(label="Kick", style=discord.ButtonStyle.danger, emoji="👢")
    async def kick_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("kick_members")(interaction):
            return
        dispatched = await _dispatch_console(
            interaction.client, f"kick {self.target_name} Kicked by staff via management panel"
        )
        msg = f"👢 Kick command dispatched for **{self.target_name}** via console bridge." if dispatched else "❌ Bridge channel unavailable — command not sent."
        await interaction.response.send_message(msg, ephemeral=True)

    @discord.ui.button(label="Ban (AdvancedBan)", style=discord.ButtonStyle.danger, emoji="🔨")
    async def ban_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not await _staff_check("ban_members")(interaction):
            return
        await interaction.response.send_modal(BanReasonModal(self.target_name, self.target_uuid))


class Minecraft2(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.servers = list(MINECRAFT_SERVERS.values())
        self.update_status_loop.start()

    def cog_unload(self):
        self.update_status_loop.cancel()

    @tasks.loop(minutes=2)
    async def update_status_loop(self):
        total_players = 0
        for addr in self.servers:
            try:
                server = await JavaServer.async_lookup(addr)
                status = await server.async_status()
                total_players += status.players.online
            except Exception:
                pass

        activity = discord.Activity(
            type=discord.ActivityType.playing,
            name=f"⚡ {total_players} Players Online | ,help",
        )
        await self.bot.change_presence(activity=activity)

    @update_status_loop.before_loop
    async def before_status_loop(self):
        await self.bot.wait_until_ready()

    @commands.command(name="bug", aliases=["reportbug"])
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def bug(self, ctx, *, issue: str):
        embed = discord.Embed(title="🐛 Bug Report Logged", description=issue, color=discord.Color.red())
        embed.add_field(name="Reported By", value=ctx.author.mention, inline=True)
        embed.add_field(name="Channel", value=ctx.channel.mention, inline=True)
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        embed.set_footer(text=f"User ID: {ctx.author.id} • {BRAND_NAME} Security")

        await ctx.send(
            f"✅ Thank you {ctx.author.mention}, your bug report has been securely dispatched to staff logs!",
            delete_after=10,
        )
        try:
            await ctx.message.delete()
        except discord.Forbidden:
            pass

    @commands.command(name="mcprofile", aliases=["profile", "player"])
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def mcprofile(self, ctx, username: str):
        if not _USERNAME_RE.match(username):
            await ctx.send("❌ That doesn't look like a valid Minecraft username (3-16 letters/numbers/underscores).")
            return

        account_type = "🟢 Premium (Online)"
        uuid_str = None

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"https://api.mojang.com/users/profiles/minecraft/{username}", timeout=aiohttp.ClientTimeout(total=5)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        uuid_str = data.get("id")
                        username = data.get("name", username)
                    else:
                        account_type = "🟡 Cracked (Offline)"
                        offline_uuid = uuid.uuid3(uuid.NAMESPACE_DNS, f"OfflinePlayer:{username}")
                        uuid_str = str(offline_uuid).replace("-", "")
        except Exception:
            await ctx.send("❌ Couldn't reach the Mojang API right now — try again shortly.")
            return

        embed = discord.Embed(
            title=f"🎮 Minecraft Profile: {username}",
            description="Network registry lookup completed.",
            color=discord.Color.blurple(),
        )
        embed.add_field(name="Username", value=f"`{username}`", inline=True)
        embed.add_field(name="Account Status", value=account_type, inline=True)
        embed.add_field(name="Network UUID", value=f"`{uuid_str}`", inline=False)
        embed.add_field(
            name="Skin Render",
            value=f"[Download Skin File](https://crafatar.com/skins/{uuid_str})",
            inline=False,
        )
        embed.set_thumbnail(url=f"https://crafatar.com/renders/head/{uuid_str}?overlay")
        embed.timestamp = datetime.datetime.now(datetime.timezone.utc)
        embed.set_footer(text=f"{BRAND_NAME} Infrastructure • Secure Control Matrix")

        view = MinecraftManagementView(username, uuid_str)
        await ctx.send(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(Minecraft2(bot))
