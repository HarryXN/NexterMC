# cogs/invsummary.py
import logging

import discord
from discord.ext import commands

from config import AI_COMMAND_COOLDOWN_SECONDS, EVENT_RULES_CHANNEL_ID
from utils.ai_client import AIConfigError
from utils.transcript import analyze_transcript, fetch_transcript_lines

log = logging.getLogger("nextermc.invsummary")


def _build_final_prompt(source_text: str, message_count: int, rules_transcript: str) -> str:
    return (
        "You are a NexterCloud free-hosting invite/reward auditor. The material below is either "
        "the raw ticket transcript (if short) or condensed factual notes extracted "
        "section-by-section from the full transcript (if long) — every part has already been "
        "read. Look for bot command outputs showing joins/left/fakes/re-joins, invite lists, and "
        "account-age checks. Do a precise arithmetic audit. If deductions exceed joins, the final "
        "count can be negative — state it plainly.\n\n"
        "Be short and direct. No filler, no restating the rules verbatim, one line per bullet "
        "where possible.\n\n"
        "Output EXACTLY this Markdown format, nothing before or after it:\n"
        "### 🎁 Free Hosting Invite Audit\n"
        "• **Claimed Invites:** [number]\n"
        "• **Verified Joins / Fakes / Re-joins:** [breakdown from bot logs]\n"
        "• **Deductions:** [arithmetic, one line]\n"
        "• **FINAL INVITES COUNT:** [net total — can be negative]\n"
        "• **Reward Eligibility:** [Met / Not Met — missing requirement if not]\n"
        "• **Next Action:** [what staff should do]\n\n"
        f"--- EVENT RULES ---\n{rules_transcript}\n\n"
        f"--- MATERIAL ({message_count} messages analyzed) ---\n{source_text}"
    )


class InvSummaryCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _fetch_rules_transcript(self) -> str:
        rules_channel = self.bot.get_channel(EVENT_RULES_CHANNEL_ID)
        if rules_channel is None:
            return "Rules channel unreachable."
        try:
            lines = []
            async for msg in rules_channel.history(limit=50, oldest_first=True):
                text = msg.content
                for embed in msg.embeds:
                    if embed.description:
                        text += f"\n{embed.description}"
                if text:
                    lines.append(text)
            return "\n".join(lines) if lines else "Rules channel is empty."
        except discord.Forbidden:
            return "Rules channel unreadable (missing permissions)."

    @commands.command(
        name="invsummary",
        help="Audits invite logs, joins/fakes, and event rules to produce a precise final invite count.",
    )
    @commands.cooldown(1, AI_COMMAND_COOLDOWN_SECONDS, commands.BucketType.channel)
    async def invsummary(self, ctx):
        loading_msg = await ctx.reply("⏳ Auditing invite claims against event rules...", mention_author=False)

        try:
            lines = await fetch_transcript_lines(ctx.channel, limit=None)
            if not lines:
                await loading_msg.edit(content="❌ No history found.")
                return

            rules_transcript = await self._fetch_rules_transcript()

            result = await analyze_transcript(
                lines, lambda src, count: _build_final_prompt(src, count, rules_transcript)
            )

            embed = discord.Embed(
                title="🎁 NexterCloud Free Plan Invite Audit",
                description=result.text[:4000],
                color=discord.Color.green(),
            )
            embed.set_footer(text=f"Requested by {ctx.author.name} • Free Plan Verification")
            await loading_msg.delete()
            await ctx.send(embed=embed)

        except AIConfigError as e:
            await loading_msg.edit(content=f"❌ {e}")
        except Exception:
            log.exception("invsummary failed in channel %s", ctx.channel.id)
            await loading_msg.edit(content="❌ Something went wrong running the audit. The issue has been logged.")


async def setup(bot):
    await bot.add_cog(InvSummaryCog(bot))
