# permissions.py
from discord.ext import commands

from config import OWNER_ID, STAFF_ROLE_IDS


def is_staff_member(ctx: commands.Context) -> bool:
    """
    Shared predicate used both by the global bot check and by the
    per-command decorator below, so the two can never drift apart.

    Staff = the owner, OR anyone with Manage Channels, OR (if configured)
    anyone holding one of STAFF_ROLE_IDS. The role-based path is the
    recommended one for a large server: permissions can be scattered
    across channel overrides, but a role is a single source of truth.
    """
    if ctx.author.id == OWNER_ID:
        return True

    if ctx.channel.permissions_for(ctx.author).manage_channels:
        return True

    if STAFF_ROLE_IDS:
        author_role_ids = {role.id for role in getattr(ctx.author, "roles", [])}
        if author_role_ids.intersection(STAFF_ROLE_IDS):
            return True

    return False


def is_staff_or_owner():
    """Command-level decorator variant of the same check, for cogs that
    want to state their requirement explicitly rather than relying only
    on the global check in main.py."""
    async def predicate(ctx: commands.Context) -> bool:
        return is_staff_member(ctx)
    return commands.check(predicate)
